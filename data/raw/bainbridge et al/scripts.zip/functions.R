# Functions ----
# sub.by.name

# This function selects variables from a df by variable name. Although this is
# easily done with "subset()" or "[" and grep, this is a neater solution.

# The following inputs are required with no default values:
#   x = name(s) of variable(s) to retain;
#   y = name of dataset to subset

# E.g., if you want all BFI items from the df dataframe, then simply enter
# x = "BFI", y = df, and all variables with BFI in their name will be selected
# from the df dataframe. Altenatively, if you want all BFI and IPIP items from
# the same dataframe, then enter x = c("BFI", "IPIP").

sub.by.name <-
  function(var_names, dataset) {
    dataset[, grepl(paste(c(var_names), collapse="|"), names(dataset))]
  }

# extract.params

# This function selects rows from data frames by a column within a list or a
# list within a list. It was designed to select particular rows from
# $parameters$stdy.parameters in an mplus object imported with MplusAutomation's
# readModels function.

# The following inputs are required although defaults have been selected for use
# with the MplusAutomation input
#    output = object with data to extract
#    text   = text to extract by as per the grep function
#    column = name of the column to look for text in
#    entry1 = list entry within text to drill into
#             (may work with NULL if text is a dataframe)
#    entry2 = list entry within entry1 to extract from
#             (may work with NULL if entry1 is a dataframe)

extract.params <- function(
  mplus_object,
  text,
  column="paramHeader",
  entry1="parameters",
  entry2="stdy.standardized"
) mplus_object[[entry1]][[entry2]][
  grep(text, mplus_object[[entry1]][[entry2]][[column]]),
]

# check.mplus

# This function checks whether or not a particular Mplus model from an .inp file
# has run or not. It's useful for enabling models that have already been run to
# be skipped. To enable compatability across different file structures, it also
# ignores the directory when making this assessment.

# First "if" checks if inp file exists. If it does not, don't run
# Second "if" check if the out file exists. If it does not, run
# Third "if" checks if inp and out match. If they do, don't run

check.mplus <- function(dir=getwd(), file) {
  if (!file.exists(file.path(dir, paste0(file, ".inp")))) FALSE else {
    if (!file.exists(file.path(dir, paste0(file, ".out")))) TRUE else {
      pattern0 <- readLines(file.path(dir, paste0(file, ".inp")))
      # Updating Lavaan/R caused small changes in outputs to measurement models.
      # Usually this was at the 14th-15th decimal place.
      # But affected as high as the 8th.
      # I want this to work for different versions of Lavaan/R, so it works for
      # those without Mplus.
      # Also, it will make very little difference.
      # Instead, just remove the 10th-15th decimals from the check.
      pattern0 <- str_replace_all(pattern0,
                                  "[0-9]{5,}",
                                  str_extract(pattern0, "[0-9]{5}"))
      pattern0 <- gsub(" ", "", pattern0)
      pattern0 <- paste(pattern0, collapse="")
      # Remove most of the data location.
      # Should make robust to different project locations.
      pattern0 <- gsub("DATA:FILE.+?mplus", "", pattern0)
      x0 <- readLines(file.path(dir, paste0(file, ".out")))
      x0 <- str_replace_all(x0,
                            "[0-9]{5,}",
                            str_extract(x0, "[0-9]{5}"))
      x0 <- gsub(" ", "", x0)
      x0 <- paste(x0, collapse="")
      x0 <- gsub("DATA:FILE.+?mplus", "", x0)
      # only 1 string. So if result=1, they match
      if (grepl(pattern0, x0, fixed=TRUE) == 1) FALSE else TRUE
    }
  }
}

# Read Mplus

# MplusAutomation's readModels() is effective, but very slow.
# The following is quicker, but only extracts fit indeces, regression
# parameters, and R^2^ values.
# It will break if applied to anything where the structural model is not a
# regression and anything that doesn't have a least two sections of output
# (e.g., standard and STDY).
# Requires `stringr` package.

# Due to Neuroticism being reversed in some orthogonal models, it needs to also
# check that the N factor has not been reversed and reverse the parameter with N
# if it has.

# file0 = the name of the file (excluding the extension).
# construct = the name of the dependent variable (can be left blank if
# identical to the file name).

read.mplus <- function(dir=getwd(), file0, factors, construct=file0) {
  tmp <- readLines(file.path(dir, paste0(file0, ".out")))
  if (grepl("NO CONVERGENCE", paste0(tmp, collapse=""))) "No convergence" else {
    chi2 <- tmp[grep("Chi-Square Test of Model Fit$", tmp) + 2:4]
    chi2 <- str_extract(chi2, "\\d+[.]*\\d*")
    cfi <- tmp[grep("CFI ", tmp)]
    cfi <- str_extract(cfi, "\\d[.]\\d+")
    tli <- tmp[grep("TLI ", tmp)]
    tli <- str_extract(tli, "\\d[.]\\d+")
    rmsea0 <- tmp[grep("RMSEA \\(Root", tmp) + 2:4]
    rmsea <- c(str_extract(rmsea0[1], "\\d[.]\\d+"),
               str_extract(rmsea0[2], "\\d[.]\\d+"),
               str_extract(rmsea0[2], "\\d[.]\\d+$"),
               str_extract(rmsea0[3], "\\d[.]\\d+"))
    srmr <- tmp[grep("SRMR \\(Standardized", tmp) + 2]
    srmr <- str_extract(srmr, "\\d[.]\\d+")
    fit <- c(chi2, cfi, tli, rmsea, srmr)
    names(fit) <- c("chisq", "df", "pvalue", "cfi", "tli", "rmsea",
                    "rmsea.ci.lower", "rmsea.ci.upper", "rmsea.pvalue", "srmr")
    fit <- sapply(fit, as.numeric)
    # 2 results for scale regression on B5.
    # We only want the second (standardiized).
    # Remove everything before that.
    tmp1 <- tmp[grep("STDY Standardization", tmp):length(tmp)]
    b_extract <- paste(toupper(construct), ".+ON")
    b <- tmp1[grep(b_extract, tmp1) + seq_along(factors)]
    b <- t(data.frame(str_extract_all(b, "-*\\d+[.]\\d+")))
    b <- apply(b, 2, as.numeric)
    rownames(b) <- factors
    colnames(b) <- c("es", "se", "t", "p")
    nl <- tmp1[grep("^\\sN\\s+BY$", tmp1) + (1:12)]  # First 12 items should be enough for the IPIP
    nl <- mean(
      as.numeric(t(as.data.frame(str_extract_all(nl, "-*\\d+[.]\\d+")))[, 1])
    )
    if (nl < 0) {
      b["n", "es"] <- -b["n", "es"]
      b["n", "t"] <- -b["n", "t"]
    }
    r2 <- tmp[grep("Latent  ", tmp) + 3]
    r2 <- str_extract_all(r2, "\\d+[.]\\d+|Undefined", simplify=TRUE)
    r2 <- as.numeric(r2[1:4])
    names(r2) <- c("es", "se", "t", "p")
    return(list(fit=fit, r2=r2, beta=b, nl=nl))
  }
}

# Read Mplus Bifactor

# As for read.mplus except it's for the bi-factor models and extracts a
# correlation matrix instead of beta weights and an R^2.
# kl should be a vector of the length of the number of group factors.

# If the ESEM is orthogonal then the corscale output will be equivalent to
# betas.

read.mplus.bif <- function(dir=getwd(), file0, kl, factors, construct=file0) {
  tmp <- readLines(file.path(dir, paste0(file0, ".out")))
  chi2 <- tmp[grep("Chi-Square Test of Model Fit$", tmp) + 2:4]
  chi2 <- str_extract(chi2, "\\d+[.]*\\d*")
  cfi <- tmp[grep("CFI ", tmp)]
  cfi <- str_extract(cfi, "\\d[.]\\d+")
  tli <- tmp[grep("TLI ", tmp)]
  tli <- str_extract(tli, "\\d[.]\\d+")
  rmsea0 <- tmp[grep("RMSEA \\(Root", tmp) + 2:4]
  rmsea <- c(str_extract(rmsea0[1], "\\d[.]\\d+"),
             str_extract(rmsea0[2], "\\d[.]\\d+"),
             str_extract(rmsea0[2], "\\d[.]\\d+$"),
             str_extract(rmsea0[3], "\\d[.]\\d+"))
  srmr <- tmp[grep("SRMR \\(Standardized", tmp) + 2]
  srmr <- str_extract(srmr, "\\d[.]\\d+")
  fit <- c(chi2, cfi, tli, rmsea, srmr)
  names(fit) <- c("chisq", "df", "pvalue", "cfi", "tli", "rmsea",
                  "rmsea.ci.lower", "rmsea.ci.upper", "rmsea.pvalue", "srmr")
  fit <- sapply(fit, as.numeric)
  # 2 results for scale regression on B5.
  # We only want the second (standardiized).
  # Remove everything before that.
  tmp1 <- tmp[grep("STDY Standardization", tmp): length(tmp)]
  cs <- tmp1[grep(paste(toupper(construct), " +WITH"), tmp1) +
               length(kl) +
               seq_along(factors)]
  cs <- t(data.frame(str_extract_all(cs, "-*\\d+[.]\\d+")))
  cs <- apply(cs, 2, as.numeric)
  rownames(cs) <- factors
  colnames(cs) <- c("es", "se", "t", "p")
  cf <- mapply(
    function(f, l) {
      tmp2 <- tmp1[grep(paste0(" ", toupper(f), " +WITH"), tmp1) + 1:l]
      tmp2 <- t(data.frame(str_extract_all(tmp2, "-*\\d+[.]\\d+")))
      tmp2 <- apply(tmp2, 2, as.numeric)
      tmp2 <- matrix(tmp2, l, 4)
      colnames(tmp2) <- c("es", "se", "t", "p")
      rownames(tmp2) <- factors[1:l]
      return(data.frame(t(tmp2)))
    },
    f=factors[-1], l=seq_along(factors[-1])
  )
  cf <- t(cbind.data.frame(cf))
  rownames(cf)[1] <- paste0(factors[2], ".", factors[1])
  nl <- tmp1[grep("^\\sN\\s+BY$", tmp1) + (1:12)]  # First 12 items should be enough for the IPIP
  nl <- mean(
    as.numeric(t(as.data.frame(str_extract_all(nl, "-*\\d+[.]\\d+")))[, 1])
  )
  if (nl < 0) {
    cs["n", "es"] <- -cs["n", "es"]
    cs["n", "t"] <- -cs["n", "t"]
  }
  return(list(fit=fit, corscale=cs, corfactors=cf))
}

# Create cormat

# Creates a correlation matrix from a vector of correlations with the scale and
# a vector of corrlations between domains (both as returned from
# read.mplus.bif, e.g.).
# cs = correlations with the scale
# cf = correlations between domains

create.cormat <- function(cs, cf, f=names(cs), sn="Scale") {
  tmp0 <- c(cs[length(cs):1], cf[length(cf):1])
  tmp <- matrix(0, length(cs) + 1, length(cs) + 1)
  tmp[col(tmp) < row(tmp)] <- tmp0
  tmp <- tmp + t(tmp)
  diag(tmp) <- 1
  rownames(tmp) <- c(sn, f[length(f):1])
  colnames(tmp) <- rownames(tmp)
  return(tmp)
}

# large

# As per the excel/libreoffice function, this selects the nth largest value from
# an object that can be sorted. However, it is based on absolute values, unlike
# the office function.

large <-
  function(object, n=2) {
    sort(abs(object), partial=length(object) - n + 1)[length(object) - n + 1]
}
